﻿using TextFileProcessor;

string path = @"C:\Users\infosys\source\repos\OOP2026\Chapter14\Section04\Program.cs";
TextProcessor.Run<WordCounterProcessor>(path);

public class WordCounterProcessor : TextProcessor
{
	private int _count = 0;
	private string word = "System";
	protected override void Initialize(string fName) =>
		_count = 0;
	protected override void Execute(string line) =>
		_count += line.Split(new char[] { ' ', '\t', '.', ',', ';', ':', '!', '?' }, StringSplitOptions.RemoveEmptyEntries).Count(w => w == word);
	protected override void Terminate() =>
		Console.WriteLine($"{word}は{_count}つ出現します。 ");
}
